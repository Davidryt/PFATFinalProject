package AST;
import Compiler.*;
import Errors.*;

 public interface Statement extends S{
 }
