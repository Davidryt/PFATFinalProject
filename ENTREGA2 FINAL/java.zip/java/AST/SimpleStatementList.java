package AST;
import Compiler.*;
import Errors.*;

public interface SimpleStatementList extends S{
}
