package AST;
import Compiler.*;
import Errors.*;

 public interface ExpLog extends S{
   
 }
