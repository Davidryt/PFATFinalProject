package AST;
import Compiler.*;
import Errors.*;

 public interface State extends S{
 }
