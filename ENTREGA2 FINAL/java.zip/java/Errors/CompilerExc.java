package Errors;

public class CompilerExc extends Exception { }

