package Errors;

public class NotAllVariables extends CompilerExc {

  public NotAllVariables() {
       }

  public String toString() {
     return "NotAllVariables: En la Inicializacion debemos tener todas las variables inicializadas, en este caso nos encontramos con que no todas estan inicializadas correctamente, por lo tanto se lanza esta excepción. ";
       }
}
