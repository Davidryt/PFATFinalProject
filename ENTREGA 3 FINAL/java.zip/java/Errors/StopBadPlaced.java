package Errors;

public class StopBadPlaced extends CompilerExc {

  public StopBadPlaced() {
       }

  public String toString() {
     return "Stop Bad Placed ";
       }
}
