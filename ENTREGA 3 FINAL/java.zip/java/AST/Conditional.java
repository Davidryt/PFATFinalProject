package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public class Conditional implements ExpLog{
    public final ExpLog a;
    public Conditional(ExpLog a){
        this.a= a;
    }
	
	public void Comprobar() throws CompilerExc{
		this.a.Comprobar();
		System.out.println("HAY UN CONDIDICONAL");
	}
	public void generateCode(BufferedWriter w) throws IOException{
		this.a.generateCode(w);
	}
	
	public void getValue(BufferedWriter w)throws IOException{
	}
	public String getString(){
		return "";
	}
	 public void obtainvalues (){}
 }