package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public class ExpLog3 implements ExpLog{
    public final String ident;
	public ExpLog3(String ident){
		this.ident=ident;
	}

	public void Comprobar() throws CompilerExc{
		 table.expcheck(this.ident);
		 System.out.print(" string " + this.ident + "\n");
	}
	
	public void getValue(BufferedWriter w)throws IOException{
		w.write("(salid.getLastValue(new Resultado(\""+this.ident+"\",false,cont);))");
	}
	
	public String getString(){
		return this.ident;
	}
	
	public void generateCode(BufferedWriter w) throws IOException{
		w.write("tem = new Resultado(\""+this.ident+"\",false,cont);");
		w.newLine();
		w.write("if(salid.getLastValue(tem)){");
		w.newLine();
	}
			 public void obtainvalues (){}
}
