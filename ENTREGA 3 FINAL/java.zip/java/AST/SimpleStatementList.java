package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

public interface SimpleStatementList extends S{
	public void generateCode(BufferedWriter w) throws IOException;
}
