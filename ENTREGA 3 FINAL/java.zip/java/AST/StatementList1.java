package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

	 public class StatementList1 implements Statement, StatementList{
		public final Statement o2;
		public final StatementList o3;
		public StatementList1(Statement o2,StatementList o3){
			this.o2=o2;
			this.o3=o3;
		}
		public StatementList1(Statement o2){
			this.o2=o2;
			this.o3=null;
		}

		public void Comprobar() throws CompilerExc{
			System.out.println("siguiente sentencia");
			if(this.o2!=null){
			this.o2.Comprobar();
			}
			if(this.o3!=null){
				this.o3.Comprobar();
			}
		}
		public void generateCode(BufferedWriter w) throws IOException{
			if(this.o2!=null){
			this.o2.generateCode(w);
			}
			if(this.o3!=null){
				this.o3.generateCode(w);
			}
		}
		
		public boolean isStop(){
			if(this.o3!=null){
			return this.o3.isStop();}
			return this.o2.isStop();
		}

		public void obtainvalues (){
			if(this.o2!=null){
			this.o2.obtainvalues();
			}
			if(this.o3!=null){
				this.o3.obtainvalues();
			}
		}

	}
