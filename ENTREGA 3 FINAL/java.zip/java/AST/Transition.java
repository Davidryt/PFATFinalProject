package AST;
import Compiler.*;
import Errors.*;

 public interface Transition extends S{
	  public void obtainvalues();
 }
