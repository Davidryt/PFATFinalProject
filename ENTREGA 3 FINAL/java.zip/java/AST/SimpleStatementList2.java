package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

public class SimpleStatementList2 implements SimpleStatementList{
	public final String ident;
	public final boolean clog;
	public SimpleStatementList2(String ident, boolean clog){
		this.ident=ident;
		this.clog=clog;
	}

	public void Comprobar() throws CompilerExc{
		System.out.println("****** String " + ident + " and " + clog);
		table.getType(ident);
		table.initsearch(ident, 8);
	}


	public void generateCode(BufferedWriter w) throws IOException{
		w.write("salid.insertaResultado(\""+ident+"\","+clog+", -1);");
		w.newLine();
	}

}
