package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public interface ExpLog extends S{
   	 public void obtainvalues ();
	 public void getValue(BufferedWriter w)throws IOException;
	 public String getString();
 }
