 package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public class ExpLog2 implements ExpLog{

  public final ExpLog a1;
    public final ExpLog a2;

 public ExpLog2(ExpLog a1, ExpLog a2){
        this.a1=a1;
        this.a2=a2;
    }
   public ExpLog2(ExpLog a1){
        this.a1=a1;
        this.a2=null;
    }

	public void Comprobar() throws CompilerExc{
		System.out.println("\t\t\tADEMAS ES NOT PUERCO");
		System.out.println("\tExp2");
		this.a1.Comprobar();
		if(this.a2 != null){
		    System.out.println("EXP EXTRA");
			this.a2.Comprobar();
		}
	}
	
	public void getValue(BufferedWriter w)throws IOException{
		w.write("false");
	}
	
	public String getString(){
		return "";
	}
	
	public void generateCode(BufferedWriter w) throws IOException{
		w.write("tem = new Resultado(\""+this.a1.getString()+"\",false,cont);");
		w.newLine();
		w.write("if(!salid.getLastValue(tem)){");
		w.newLine();
	}
			 public void obtainvalues (){}
}
