package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

public class Transitions implements TransitionList{
	public final TransitionList t4;
	public Transitions(TransitionList t4){
		this.t4=t4;
	}

	public void Comprobar() throws CompilerExc{
		this.t4.Comprobar();
	}

	public void generateCode(BufferedWriter w) throws IOException{
		this.t4.generateCode(w);
	}

	public void obtainvalues (){
		this.t4.obtainvalues();
	}


}
