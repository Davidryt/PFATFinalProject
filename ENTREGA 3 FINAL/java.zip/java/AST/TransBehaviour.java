package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public class TransBehaviour implements StatementList{
		public final StatementList o1;
		public TransBehaviour(StatementList o1){
			this.o1=o1;
		}

		public void Comprobar() throws CompilerExc{
			if(this.o1!=null){
			this.o1.Comprobar();
			}
		}
		public void generateCode(BufferedWriter w) throws IOException{
			this.o1.generateCode(w);
		}

	public boolean isStop(){
		return this.o1.isStop();
	}

	public void obtainvalues (){
		this.o1.obtainvalues();
	}


	}
