package AST;
import Compiler.*;
import Errors.*;
import java.io.*;


 public interface S{
   public static SymbolTable table = new SymbolTable();
   public void Comprobar() throws CompilerExc;
   public void generateCode(BufferedWriter w) throws IOException;
 }
