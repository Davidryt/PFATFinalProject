package AST;
import Compiler.*;
import Errors.*;

 public interface IdentList extends S{
	 public void Comprobar(int type) throws CompilerExc;
 }
