package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public class ExpLog1 implements ExpLog{
    public final boolean clog;

  public ExpLog1(boolean clog){
        this.clog = clog;
     }

	 public void Comprobar() throws CompilerExc{
		 System.out.println(" boolean " + this.clog);
	 }
	 public void generateCode(BufferedWriter w) throws IOException{

	}

  public void getValue(BufferedWriter w)throws IOException{
	  String value;
	  if(clog){
		  value="true";
	  }else{
		  value="false";
	  }
	w.write(value);
  }
  
  public String getString(){
		return "";
	}
  

		 public void obtainvalues (){
			 if(this.clog){
				 System.out.println("\t\tNEW VALUE: 1");
			 }else{
				 System.out.println("\t\tNEW VALUE: 0");
			 }
		 }
}
