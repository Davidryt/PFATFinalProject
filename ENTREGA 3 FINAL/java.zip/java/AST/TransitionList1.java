package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

public class TransitionList1 implements Transition,TransitionList{
	public final Transition t1;
	public final TransitionList t2;
	public TransitionList1(Transition t1){
		this.t1=t1;
		this.t2=null;
	}

	public TransitionList1(Transition t1, TransitionList t2){
		this.t1=t1;
		this.t2=t2;
	}

  public void Comprobar() throws CompilerExc{
		System.out.println("SIGUIENTE TRANSICION");
		this.t1.Comprobar();
		if(this.t2 != null){
			this.t2.Comprobar();
		}
  }

	public void generateCode(BufferedWriter w) throws IOException{
		this.t1.generateCode(w);
		if(this.t2 != null){
			this.t2.generateCode(w);
		}
	}

	public void obtainvalues(){
		System.out.println("OBTENIENDO VALORES");
		this.t1.obtainvalues();
		if(this.t2 != null){
			this.t2.obtainvalues();
		}
	}


}
