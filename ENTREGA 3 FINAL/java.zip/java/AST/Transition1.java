package AST;
import Compiler.*;
import Errors.*;
import java.io.*;
  public class Transition1 implements Transition{

  public final InitialState f1;
	public final Event f2;
	public final FinalState f3;
	public final TransBehaviour f7;
	 public final Conditional f11;

	public Transition1(InitialState f1, Event f2, FinalState f3){
		this.f1=f1;
		this.f2=f2;
		this.f3=f3;
		this.f7=null;
		this.f11=null;
	}

	public Transition1(InitialState f1, Event f2, FinalState f3, TransBehaviour f7){
		this.f1=f1;
		this.f2=f2;
		this.f3=f3;
		this.f7=f7;
		this.f11=null;
	}

 public Transition1(InitialState f1, Event f2, FinalState f3, Conditional f11){
	 this.f1=f1;
	 this.f2=f2;
	 this.f3=f3;
	 this.f7=null;
	 this.f11=f11;
 }

 public Transition1(InitialState f1, Event f2, FinalState f3, Conditional f11, TransBehaviour f7){
	 this.f1=f1;
	 this.f2=f2;
	 this.f3=f3;
	 this.f7=f7;
	 this.f11=f11;
 }

 public void Comprobar() throws CompilerExc{
   table.newEntry(f1.getString(), f2.getString(), 6);
   this.f1.Comprobar();
   this.f2.Comprobar();
   this.f3.Comprobar();
   if(this.f7!=null){
	   System.out.println("\n\n TRANSBEHAVIOUR\n");
	   this.f7.Comprobar();
   }
   if (this.f11!=null){
	    //System.out.println("\n\n CONDICIONAL\n");
   this.f11.Comprobar();
   //System.out.println("\n\n");}
 }

 }
public void generateCode(BufferedWriter w) throws IOException{
	w.write("if(cont>=lec.size()){break;}");
	w.newLine();
	w.write("if(ActualState.equals(\""+f1.getString()+"\") && input.equals(\""+f2.getString()+"\")){");
	w.newLine();
	
	if(this.f11!=null){
		this.f11.generateCode(w);
	}
	if(this.f7!=null){
		this.f7.generateCode(w);
	System.out.println("\t\t"+this.f7.isStop());}
	w.write("stop--;");
	w.newLine();
	w.write("ActualState = \""+ this.f3.getString() + "\";");
	w.newLine();
	if(this.f11!=null){
		w.write("}");
		w.newLine();
	}
	w.write("salid.rellenar(cont);");
	w.newLine();
	w.write("cont++;");
	w.newLine();
	w.write("if(cont<lec.size()){input=lec.get(cont).toString();}");
	w.newLine();
	
	int fin = table.count(2);
	System.out.println("\t\t\t\tEL VALOR DE FIN ES "+ fin);
	if(fin!=0){
	w.write("for(int j=0; j<finalstate.size(); j++){");
	w.newLine();
	w.write("String check = (String) finalstate.get(j);");
	w.newLine();
	w.write("if(ActualState.equals(check)){");
	w.newLine();
	w.write("break whileloop;");
	w.newLine();
	w.write("}");
	w.newLine();
	w.write("}");
	w.newLine();
	}
	
	if(this.f7!=null && this.f7.isStop()){
		//w.write("salid.rellenar(cont);");
		w.write("break whileloop;");
		w.newLine();
	}
	
	w.write("}");
	w.newLine();
}

 public void obtainvalues(){
	if(this.f7!=null){
	   System.out.println("Hay behaviour");
	   this.f7.obtainvalues();
   }else{
	   System.out.println("nada");
   }
 }
 }
