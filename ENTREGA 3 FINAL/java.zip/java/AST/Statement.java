package AST;
import Compiler.*;
import Errors.*;
import java.io.*;

 public interface Statement extends S{
	 	 public void obtainvalues ();
		 public boolean isStop();
 }
