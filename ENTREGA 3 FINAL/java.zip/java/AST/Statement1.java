package AST;
import Compiler.*;
import Errors.*;
import java.io.*;
   public class Statement1 implements Statement, ExpLog, StatementList{
		 public final int cint;
		 public final String ident;
		 public final ExpLog a3;
		 public final StatementList s4;
		 public Statement1(int cint){
			 this.cint= cint;
			 this.s4=null;
			 this.a3=null;
			 this.ident=null;
		 }
		public Statement1(){
			this.cint=-1;
			this.s4=null;
			this.a3=null;
			this.ident=null;
		}

		public Statement1(String ident, ExpLog a3){
			this.ident=ident;
			this.cint=-1;
			this.a3=a3;
			this.s4=null;
		}

		public Statement1(ExpLog a3, StatementList s4){
			 this.a3=a3;
			 this.s4=s4;
			 this.cint=-1;
			 this.ident=null;
		}

		public void Comprobar() throws CompilerExc{

			if(this.a3!=null && this.cint==-1&& this.ident==null){
				System.out.println("\t\t\tES UN IF CERDO");
			}

			if(this.ident != null){
				System.out.println("STRING --> " + this.ident);
				table.asigsearch(ident, 4, 7);
			}

			if(this.a3!=null){
				System.out.print("EXP --> ");
				this.a3.Comprobar();
			}

			System.out.println("NUMERO --> "+ this.cint);

			if(this.a3==null && this.cint==-1&& this.ident==null&&this.s4==null){
				System.out.println("\t\t\tSTOP RIGHT HERE");
			}

			if(this.s4!=null){
				this.s4.Comprobar();
			}
		}

    public void generateCode(BufferedWriter w) throws IOException{
		if(this.cint!=-1){
			System.out.println("HAY SLEEP");
			w.write("int h =0;");
			w.newLine();
			w.write("for(h=cont; h<(cont+"+this.cint+");h++){");
			w.newLine();
			w.write("salid.rellenar(h);");
			w.newLine();
			w.write("}");
			w.newLine();
			w.write("cont=h;");
			w.newLine();
		}

		

		if(this.ident!=null && this.a3!=null){
		w.write("salid.insertaResultado(\""+this.ident+"\",");
		this.a3.getValue(w);
		w.write(", cont);");
		w.newLine();
		}

		if(this.a3!=null && this.cint==-1&& this.ident==null){
			this.a3.generateCode(w);
			if(this.s4!=null){
				System.out.println("HAY mas 2");
			this.s4.generateCode(w);
			}

			w.write("}");
			w.newLine();
		}
		
		// if(this.a3==null && this.cint==-1&& this.ident==null&&this.s4==null){
			// w.write("salid.rellenar(cont);");
			// w.write("break whileloop;");
			// w.newLine();
		// }

    }

	public String getString(){
		return "";
	}
	
	public boolean isStop(){
		if(this.a3==null && this.cint==-1&& this.ident==null&&this.s4==null){
			return true;
		}else{
			return false;
		}
	}

	public void getValue(BufferedWriter w)throws IOException{
	}

	public void obtainvalues (){

		if(this.a3!=null){
				System.out.println("STRING --> " + this.ident);
				this.a3.obtainvalues();
			}

	}


	}
