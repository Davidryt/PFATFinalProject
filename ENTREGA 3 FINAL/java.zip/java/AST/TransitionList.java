package AST;
import Compiler.*;
import Errors.*;

 public interface TransitionList extends S{
	 public void obtainvalues();
 }
