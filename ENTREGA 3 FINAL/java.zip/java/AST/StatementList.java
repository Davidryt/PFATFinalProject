package AST;
import Compiler.*;
import Errors.*;

 public interface StatementList extends S{
	 
	 public void obtainvalues ();
	 public boolean isStop();
 }
