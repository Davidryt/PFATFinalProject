package AST;
import Compiler.*;
import Errors.*;
import java.io.*;


public class S1 implements S {

	public final StateDeclList statedeclist; //Estado Inicial
	public final FinalStateDeclList finalstatedecllist; //Estado Final
	public final InputEventDecl inputeventdecl; //Evento de entrada
	public final LocalVarDecl localvardecl;  //Variable de entrada y de salida
	public final OutputEventDecl outputevendecl; //Evento de salida
	public final Initialization initialization; //Inicializaciones
	public final Transitions transitions;       //Transiciones


	public S1( StateDeclList statedeclist, FinalStateDeclList finalstatedecllist, InputEventDecl inputeventdecl,LocalVarDecl localvardecl,
	OutputEventDecl outputevendecl, Initialization initialization, Transitions transitions){

		this.statedeclist= statedeclist;
		this.finalstatedecllist = finalstatedecllist;
		this.inputeventdecl = inputeventdecl;
		this.localvardecl = localvardecl;
		this.outputevendecl = outputevendecl;
		this.initialization = initialization;
		this.transitions = transitions;

	}

	 public S1( StateDeclList statedeclist, FinalStateDeclList finalstatedecllist,InputEventDecl inputeventdecl, OutputEventDecl outputevendecl, Initialization initialization,
   Transitions transitions){

    	this.statedeclist= statedeclist;
    	this.finalstatedecllist= finalstatedecllist;
    	this.inputeventdecl = inputeventdecl;
    	this.outputevendecl = outputevendecl;
    	this.initialization = initialization;
    	this.transitions = transitions;
		this.localvardecl = null;


    }

	public S1( StateDeclList statedeclist, InputEventDecl inputeventdecl, LocalVarDecl localvardecl,OutputEventDecl outputevendecl,Initialization initialization,
   Transitions transitions){
      this.statedeclist = statedeclist;
	  this.finalstatedecllist = null;
      this.inputeventdecl= inputeventdecl;
      this.localvardecl = localvardecl;
      this.outputevendecl = outputevendecl;
      this.initialization = initialization;
      this.transitions= transitions;



 	}

	public S1(StateDeclList statedeclist,InputEventDecl inputeventdecl, OutputEventDecl outputevendecl,Initialization initialization,Transitions transitions){
	   this.statedeclist = statedeclist;
	   this.finalstatedecllist = null;
       this.inputeventdecl = inputeventdecl;
	   this.localvardecl = null;
       this.outputevendecl = outputevendecl;
       this.initialization = initialization;
       this.transitions = transitions;


    }

		public void Comprobar() throws CompilerExc{
			// if(initialstate.Comprobar().equals(finalstate.Comprobar())){
				// throw new DoubleDefException();
			// }
			// System.out.println("Se add");
			// tabla.newEntry("hola", true);
			// System.out.println("Se ha add");
			if (statedeclist!=null){
				statedeclist.Comprobar();
			}
			if (finalstatedecllist!=null){
				finalstatedecllist.Comprobar();
			}
			if (inputeventdecl!=null){
				inputeventdecl.Comprobar();
			}
			if (localvardecl!=null){
				System.out.println("HAY LOCAL VAR DLV");
				localvardecl.Comprobar();
			}
			if (outputevendecl!=null){
				System.out.println("HAY OUTEVENT");
				outputevendecl.Comprobar();
		
			}
			if (initialization!=null){
				initialization.Comprobar();
				int check = table.count(8);
				int all = table.count(4) + table.count(7);
				System.out.println("The value of check is "+ check);
				System.out.println("The value of all is "+ all);
				if(check<all){
					throw new NotAllVariables();
				}
			}
			if (transitions!=null){
				System.out.println("HAY TRANSITION");
				transitions.Comprobar();
			}

		}
		
		public void generateCode(BufferedWriter w) throws IOException{
			
			/* Aqui iria el main que ya tenemos + una llama a la funcion progammName
			*/
			
		w.write("public static Vector lectura (String ent){");
		w.newLine();
		w.write("Entradas entrada = new Entradas();");
		w.newLine();
		w.write("try{");
		w.newLine();
		w.write("String route = ent;");
		w.newLine();
		w.write("BufferedReader objReader = new BufferedReader(new FileReader(route));");
		w.newLine();
		w.write("Vector lec = entrada.obtener(objReader);");
		w.newLine();
		w.write("for(int i=0; i< lec.size(); i++){System.out.println(lec.get(i)); }");
		w.newLine();
		w.write("return lec;");
		w.newLine();
		w.write("}catch(Exception e){System.out.println(e.toString());}");
		w.newLine();
		w.write("return null;}	");
		w.newLine();
		w.newLine();
		
		
		w.write("public static void escritura(String sal, Vector lec){");
		w.newLine();
		w.write("try{");
		w.newLine();
		w.write("String route = sal;");
		w.newLine();
		w.write("BufferedWriter objReader = new BufferedWriter(new FileWriter(route));");
		w.newLine();
		w.write("Salida salid = new Salida(objReader);");
		w.newLine();
		w.write("String ActualState= \"" + this.initialization.getIdent()+"\";");
		w.newLine();
		this.initialization.generateCode(w);
		if(this.finalstatedecllist!=null){
			this.finalstatedecllist.generateCode(w);
		}
		w.write("int cont = 0;");
		w.newLine();
		w.write("String input = lec.get(cont).toString();");
		w.newLine();
		w.write("int stop =0;");
		w.newLine();
		w.write("Resultado tem;");
		w.newLine();
		w.write("whileloop:");
		w.newLine();
		w.write("while(stop < 100){");
		w.newLine();
		this.transitions.generateCode(w);
		w.newLine();
		w.write("if(cont>=lec.size()){break;}");
		w.newLine();
		w.write("if(stop>0){");
		w.newLine();
		w.write("salid.rellenar(cont);");
		w.newLine();
		w.write("stop--;");
		w.newLine();
		w.write("cont++;");
		w.newLine();
		w.write("if(cont<lec.size()){input=lec.get(cont).toString();}");
		w.newLine();
		w.write("}");
		w.newLine();
		w.write("stop++;");
		w.newLine();
		w.write("}");
		w.newLine();
		w.write("salid.generarResultado();");
		w.newLine();
		
	
		w.write("}catch(Exception e){System.out.println(e.toString());}}");
		w.newLine();
		w.newLine();
		
		
		w.write("public static void main(String args[]){");
		w.newLine();
		w.write("String ent = args[0];");
		w.newLine();
		w.write("String sal = args[1];");
		w.newLine();
		w.write("System.out.println(\"Leo una entrada de : \"+ ent + \"Y una salida de : \"+sal);");
		w.newLine();
		w.write("Vector <Variable> _v = new Vector <Variable>();");
		w.newLine();
		w.write("escritura(sal, lectura(ent));");
		w.newLine();
		w.write("}");
		w.newLine();
		w.newLine();
		}


}
