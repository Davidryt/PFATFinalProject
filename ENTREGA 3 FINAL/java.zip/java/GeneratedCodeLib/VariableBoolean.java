package GeneratedCodeLib;
import java.io.*;
import java.util.*;

public class VariableBoolean extends Variable {

private boolean valor;

public VariableBoolean(String name, boolean valor){
  super(name);
  this.valor=valor;
}

public boolean getValor(){
  return valor;
}
}
