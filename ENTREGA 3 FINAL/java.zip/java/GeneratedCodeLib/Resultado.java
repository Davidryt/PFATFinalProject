package GeneratedCodeLib;

public class Resultado {
  public final String var;
  public final boolean valor;
  public final int tiempo;

  public Resultado(String v, boolean val, int t) {
    var=v;
    valor=val;
    tiempo=t;
  }

  
}

