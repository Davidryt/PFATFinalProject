package GeneratedCodeLib;
import java.io.*;
import java.util.*;

public class VariableInt extends Variable {

private Integer valor;

public VariableInt(String name, Integer valor){
  super(name);
  this.valor=valor;
}

public Integer getValor(){
  return valor;
}
}
