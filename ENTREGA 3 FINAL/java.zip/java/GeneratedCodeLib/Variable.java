package GeneratedCodeLib;
import java.io.*;
import java.util.*;

public class Variable {

private String name;

public Variable(String name){
  this.name= name;
}

public String getNombre(){
  return name;
}

}
