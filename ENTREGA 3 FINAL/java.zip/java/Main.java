import Parser.*;
import Lexer.*;
import java.io.*;
import AST.*;

public class Main
{
  public static void main(String args[]) throws Exception{
    java.io.BufferedReader in;
    Yylex_skel sc;
    parser p;
    java_cup.runtime.Symbol sroot;
    boolean error=false;
	S Prog;

    //El primer parametro es el nombre del fichero con el programa
    if (args.length < 1) {
      System.out.println(
        "Uso: java Main <nombre_fichero>");
      error=true;
    }

    //An�lisis l�xico y sint�ctico

    if (!error) {
	try {
	    in = new java.io.BufferedReader(new java.io.FileReader(args[0]));
	    sc = new Yylex_skel(in);
	    p = new parser(sc);
	    sroot = p.parse();
		Prog = (S)sroot.value;
		System.out.println("Se viene");
		Prog.Comprobar();
		System.out.println("Se vino");
	    System.out.println("Analisis lexico y sintactico correctos");
		codeGenerator(args[0] , Prog);
	} catch(IOException e) {
	    System.out.println("Error abriendo fichero: " + args[0]);
	    error= true;
	}
    }
  }

  private static void codeGenerator(String className, S Prog){
    try{
	int index = className.indexOf('.');
	String classNameNew = className.substring(0,index);
      BufferedWriter w = new BufferedWriter(new FileWriter(classNameNew + ".java"));
      w.write("import GeneratedCodeLib.*;");
      w.newLine();
      w.write("import java.util.*;");
      w.newLine();
	  w.write("import java.io.*;");
      w.newLine();
      w.write("public class " + classNameNew + " {");
      w.newLine();
      w.newLine();
      Prog.generateCode(w);
      w.newLine();
      w.write("}");
      w.close();
      System.out.println("Code generated in file " + classNameNew + ".java");
    }catch(IOException e){
      System.out.println("IO error trying to write in file" + className + ".java");
    }
  }
  }

