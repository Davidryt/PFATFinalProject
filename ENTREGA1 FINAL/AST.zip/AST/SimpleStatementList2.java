package AST;

public class SimpleStatementList2 implements SimpleStatementList{
	public final String ident;
	public final boolean clog;
	public SimpleStatementList2(String ident, boolean clog){
		this.ident=ident;
		this.clog=clog;
	}
}