package AST;

public class LocalVarDecl implements IdentList{
	public final IdentList x2;
	public LocalVarDecl(IdentList x2){
		this.x2=x2;
	}
}