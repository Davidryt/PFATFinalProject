package AST;

public class InputEventDecl implements IdentList{
	public final IdentList x3;
	public InputEventDecl(IdentList x3){
		this.x3=x3;
	}
}