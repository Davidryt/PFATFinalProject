package AST;

 public class ExpLog3 implements ExpLog{
    public final String ident;
	public ExpLog3(String ident){
		this.ident=ident;
	}
}	
	