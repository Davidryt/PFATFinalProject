package AST;

 public interface Statement{}