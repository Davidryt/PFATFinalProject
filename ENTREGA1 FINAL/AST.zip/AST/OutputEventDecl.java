package AST;

public class OutputEventDecl implements IdentList{
	public final IdentList x1;
	public OutputEventDecl(IdentList x1){
		this.x1 = x1;
	}
}
