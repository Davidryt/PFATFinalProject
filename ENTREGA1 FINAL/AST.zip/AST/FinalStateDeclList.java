package AST;

public class FinalStateDeclList implements IdentList{
	public final IdentList y1;
	public FinalStateDeclList(IdentList y1){
		this.y1=y1;
	}
}