package AST;

	 public class FinalState{
		public final String i1;
		public FinalState(String i1){
			this.i1=i1;
		}
	}