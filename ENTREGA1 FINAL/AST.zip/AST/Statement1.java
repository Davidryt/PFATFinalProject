package AST;


   public class Statement1 implements Statement, ExpLog, StatementList{
		 public final int cint;
		 public final String ident;
		 public final ExpLog a3;
		 public final StatementList s4;
		 public Statement1(int cint){
			 this.cint= cint;
			 this.s4=null;
			 this.a3=null;
			 this.ident=null;
		 }
		public Statement1(){
			this.cint=0;
			this.s4=null;
			this.a3=null;
			this.ident=null;
		}

		public Statement1(String ident, ExpLog a3){
			this.ident=ident;
			this.cint=0;
			this.a3=a3;
			this.s4=null;
		}
		
		public Statement1(ExpLog a3, StatementList s4){
			 this.a3=a3;
			 this.s4=s4;
			 this.cint=0;
			 this.ident=null;
		}
	}