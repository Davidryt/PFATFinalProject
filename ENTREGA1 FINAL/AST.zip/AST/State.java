package AST;

 public interface State{}