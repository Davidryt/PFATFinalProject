package AST;

 public class TransBehaviour implements StatementList{
		public final StatementList o1;
		public TransBehaviour(StatementList o1){
			this.o1=o1;
		}
	}