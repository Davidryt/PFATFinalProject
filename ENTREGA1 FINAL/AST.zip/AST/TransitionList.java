package AST;

 public interface TransitionList{}