 package AST;

 public class ExpLog2 implements ExpLog{
 
  public final ExpLog a1;
    public final ExpLog a2;
 
 public ExpLog2(ExpLog a1, ExpLog a2){
        this.a1=a1;
        this.a2=a2;
    }
   public ExpLog2(ExpLog a1){
        this.a1=a1;
        this.a2=null;
    }
}