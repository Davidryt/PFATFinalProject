package AST;

	 public class Event{
		public final String i2;
		public Event(String i2){
			this.i2=i2;
		}
	}