package AST;

public interface SimpleStatementList{}