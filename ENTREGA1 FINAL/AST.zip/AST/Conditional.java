package AST;

 public class Conditional implements ExpLog{
    public final ExpLog a;
    public Conditional(ExpLog a){
        this.a= a;
    }
 }