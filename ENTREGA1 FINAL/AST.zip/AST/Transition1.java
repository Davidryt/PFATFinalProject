package AST;

  public class Transition1 implements Transition{
  public final InitialState f1;
	public final Event f2;
	public final FinalState f3;
	public final TransBehaviour f7;
	 public final Conditional f11;
	public Transition1(InitialState f1, Event f2, FinalState f3){
		this.f1=f1;
		this.f2=f2;
		this.f3=f3;
		this.f7=null;
		this.f11=null;
	}

	public Transition1(InitialState f1, Event f2, FinalState f3, TransBehaviour f7){
		this.f1=f1;
		this.f2=f2;
		this.f3=f3;
		this.f7=f7;
		this.f11=null;
	}

 public Transition1(InitialState f1, Event f2, FinalState f3, Conditional f11){
	 this.f1=f1;
	 this.f2=f2;
	 this.f3=f3;
	 this.f7=null;
	 this.f11=f11;
 }

 public Transition1(InitialState f1, Event f2, FinalState f3, Conditional f11, TransBehaviour f7){
	 this.f1=f1;
	 this.f2=f2;
	 this.f3=f3;
	 this.f7=f7;
	 this.f11=f11;
 }
 }