package AST;


 public interface IdentList{}