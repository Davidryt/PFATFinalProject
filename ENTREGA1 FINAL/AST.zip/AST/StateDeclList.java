package AST;

public class StateDeclList implements IdentList{
	public final IdentList y2;
	public StateDeclList(IdentList y2){
		this.y2=y2;
	}
}