package AST;

public class S1 implements S {

	public final StateDeclList statedeclist;
	public final FinalStateDeclList finalstatedecllist;
	public final InputEventDecl inputeventdecl;
	public final LocalVarDecl localvardecl;
	public final OutputEventDecl outputevendecl;
	public final Initialization initialization;
	public final Transitions transitions;

	public S1( StateDeclList statedeclist, FinalStateDeclList finalstatedecllist, InputEventDecl inputeventdecl,LocalVarDecl localvardecl,
	OutputEventDecl outputevendecl, Initialization initialization, Transitions transitions){
		
		this.statedeclist= statedeclist;
		this.finalstatedecllist = finalstatedecllist;
		this.inputeventdecl = inputeventdecl;
		this.localvardecl = localvardecl;
		this.outputevendecl = outputevendecl;
		this.initialization = initialization;
		this.transitions = transitions;

	}
	
	 public S1( StateDeclList statedeclist, FinalStateDeclList finalstatedecllist,InputEventDecl inputeventdecl, OutputEventDecl outputevendecl, Initialization initialization,
   Transitions transitions){
    	
    	this.statedeclist= statedeclist;
    	this.finalstatedecllist= finalstatedecllist;
    	this.inputeventdecl = inputeventdecl;
    	this.outputevendecl = outputevendecl;
    	this.initialization = initialization;
    	this.transitions = transitions;
		this.localvardecl = null;

    }
	
	public S1( StateDeclList statedeclist, InputEventDecl inputeventdecl, LocalVarDecl localvardecl,OutputEventDecl outputevendecl,Initialization initialization,
   Transitions transitions){
      this.statedeclist = statedeclist;
	  this.finalstatedecllist = null;
      this.inputeventdecl= inputeventdecl;
      this.localvardecl = localvardecl;
      this.outputevendecl = outputevendecl;
      this.initialization = initialization;
      this.transitions= transitions;


 	}
	
	public S1(StateDeclList statedeclist,InputEventDecl inputeventdecl, OutputEventDecl outputevendecl,Initialization initialization,Transitions transitions){
	   this.statedeclist = statedeclist;
	   this.finalstatedecllist = null;
       this.inputeventdecl = inputeventdecl;
	   this.localvardecl = null;
       this.outputevendecl = outputevendecl;
       this.initialization = initialization;
       this.transitions = transitions;

    }

}