package AST;

 public interface ExpLog{}