package AST;

 public interface Transition{}