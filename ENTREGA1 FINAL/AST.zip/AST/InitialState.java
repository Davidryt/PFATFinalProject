package AST;

 public class InitialState{
	 public final String i3;
	 public InitialState(String i3){
		 this.i3=i3;
	 }
 }