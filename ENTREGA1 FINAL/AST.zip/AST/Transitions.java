package AST;

public class Transitions implements TransitionList{
	public final TransitionList t4;
	public Transitions(TransitionList t4){
		this.t4=t4;
	}

}