package AST;

 public class ExpLog1 implements ExpLog{
    public final boolean clog;
	
  public ExpLog1(boolean clog){
        this.clog = clog;
     }
}
